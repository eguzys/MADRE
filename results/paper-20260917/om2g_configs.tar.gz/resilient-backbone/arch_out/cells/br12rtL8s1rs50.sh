#!/bin/bash
#SBATCH --job-name=br12rtL8s1rs50
#SBATCH -o /usr/itetnas04/data-scratch-01/eguzys/data/resilient-backbone/om2g_logs/cells/br12rtL8s1rs50.out
#SBATCH -e /usr/itetnas04/data-scratch-01/eguzys/data/resilient-backbone/om2g_logs/cells/br12rtL8s1rs50.err
#SBATCH --cpus-per-task=20
#SBATCH --mem=48G
#SBATCH --time=48:00:00
#SBATCH -p cpu.normal,gpu.normal,disco.med
# wave-1 post-compress-fix cell (2026-09-05). e2e primary + frozen control.
export OM2G_USER_SPAWN=archipelago
export OM2G_CLUSTERS=4
export OM2G_ARENA=3800
export OM2G_SPREAD=25
export OM2G_PCROSS=0.9
export OM2G_DRONES=8
export OMNET_NUM_DRONES=8
export OM2G_MINSEP=1200
export OM2G_MAXNN=1500
export OM2G_MARGIN=300
export OM2G_SPAWN=explore
export OM2G_SHAPE_FIEDLER=65.97
export OM2G_SHAPE_VORONOI=33.24
export OM2G_SHAPE_EDGE=9.089
export OM2G_SHAPE_SPREAD=0
export OMNET_ALLOW_CPU=1
export OM2G_LP_PRUNE_BPS=100
export OMP_NUM_THREADS=8
export MKL_NUM_THREADS=8
export OM2G_CTRL_SPREADING=8
export OM2G_PHYSICAL_METRIC=1
export OM2G_P_SCAFFOLD=0.5
export OM2G_P_RANDOM=0.75
export OM2G_USER_PARTNER_TAG=1
export OM2G_PARTNER_TAG_MODE=group
export OMNET_PEER_LINK_MASK=1
export OM2G_PEER_MEMORY=1
export OM2G_EXTRA_OVERRIDES="experiment.lr=1e-3 experiment.checkpoint_interval=24000 experiment.sampling_device=cpu experiment.train_device=cpu experiment.buffer_device=cpu"
export OM2G_RUN_TAG=br12rtL8s1rs50
export OM2G_TMPDIR=/usr/itetnas04/data-scratch-01/eguzys/data/tmp/br12rtL8s1rs50
mkdir -p $OM2G_TMPDIR
export OM2G_LATENT_DIM=8
# ROUND-TRIP arm (2026-09-06): identical wire to v1200e2eL8s1
# (4L+56 = 88 B), but the receiver expands the L wire floats to a
# constant OM2G_RT_WIDTH before the set-transformer, so the peer token is
# the same shape at every L. See staging/om2g_rt_patch.py.
export OM2G_CODEC_MODE=e2e_rt
export OM2G_RT_WIDTH=128
export OM2G_RT_HIDDEN=256
cd /usr/itetnas04/data-scratch-01/eguzys/data/resilient-backbone
# ---- corrected 1200 m shaping triple, round-trip chain (2026-09-08) ----
export OM2G_SHAPE_FIEDLER=9.603
export OM2G_SHAPE_VORONOI=2.789
export OM2G_SHAPE_EDGE=0.7233
export OM2G_DEMAND_RESHUFFLE_STEPS=50
export OM2G_RESUME_FROM=/usr/itetnas04/data-scratch-01/eguzys/data/u100diag_ckpts/L8_rs_s1/checkpoints/checkpoint_264000.pt
export OMNET_RESUME_MAX_FRAMES=312000
export OMNET_EXPECT_ENT=0.01
bash om2g/om2g_launch_arton.sh compressed st 1 300000
