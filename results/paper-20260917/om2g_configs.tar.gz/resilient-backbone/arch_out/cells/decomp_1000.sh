#!/bin/bash
#SBATCH --job-name=decomp_1000
#SBATCH -o /usr/itetnas04/data-scratch-01/eguzys/data/resilient-backbone/om2g_logs/cells/decomp_1000.out
#SBATCH -e /usr/itetnas04/data-scratch-01/eguzys/data/resilient-backbone/om2g_logs/cells/decomp_1000.err
#SBATCH --cpus-per-task=20
#SBATCH --mem=48G
#SBATCH --time=12:00:00
#SBATCH -p cpu.normal
# C4 of the e2e endorsement: offline planner-information ladder, world 1000 m.
export OM2G_USER_SPAWN=archipelago
export OM2G_CLUSTERS=4
export OM2G_ARENA=3800
export OM2G_SPREAD=25
export OM2G_PCROSS=0.9
export OM2G_DRONES=8
export OMNET_NUM_DRONES=8
export OM2G_MINSEP=1000
export OM2G_MAXNN=1200
export OM2G_MARGIN=300
export OMNET_ALLOW_CPU=1
export OM2G_LP_PRUNE_BPS=100
export OM2G_CTRL_SPREADING=8
export OM2G_PHYSICAL_METRIC=1
export OM2G_USER_PARTNER_TAG=1
export OM2G_PARTNER_TAG_MODE=group
export OM2G_PEER_MEMORY=1
export OM2G_SPAWN=cluster
export OM2G_TRACK=1
export OMP_NUM_THREADS=1
export MKL_NUM_THREADS=1
cd /usr/itetnas04/data-scratch-01/eguzys/data/resilient-backbone
export SCRATCH=/usr/itetnas04/data-scratch-01/eguzys/data
source $SCRATCH/miniconda3/etc/profile.d/conda.sh; conda activate $SCRATCH/padre_env
export OMNET_APPTAINER_SIF=$SCRATCH/omnet.sif OMNET_HOST_CODE=/usr/itetnas04/data-scratch-01/eguzys/data/resilient-backbone OMNET_CONTAINER_CODE=/work
export OMNET_INET_DIR=/opt/inet4.6 OMNETPP_DIR=/opt/omnetpp-6.4.0
eval "$(python om2g/om2g_config.py --arm nocontrol --shell)"
python om2g/om2g_info_ladder.py --tiers t0,t1,t2,t2p,t3 --seeds 100 --world-tag 1000 --out om2g_out/info_decomp_1000.csv --procs 18
echo === INFO LADDER 1000 DONE ===
