#!/bin/bash
#SBATCH --job-name=c6ent001
#SBATCH -o /usr/itetnas04/data-scratch-01/eguzys/data/resilient-backbone/om2g_logs/cells/c6ent001.out
#SBATCH -e /usr/itetnas04/data-scratch-01/eguzys/data/resilient-backbone/om2g_logs/cells/c6ent001.err
#SBATCH --gres=gpu:geforce_rtx_2080_ti:1
#SBATCH --cpus-per-task=8
#SBATCH --mem=48G
#SBATCH --time=24:00:00
#SBATCH -p gpu.normal,disco.med
# ---- the banded archipelago -------------------------------------------------
export OM2G_USER_SPAWN=archipelago
export OM2G_CLUSTERS=4
export OM2G_ARENA=3800
export OM2G_SPREAD=25
export OM2G_PCROSS=0.9
export OM2G_DRONES=8
export OMNET_NUM_DRONES=8
export OM2G_MINSEP=1465
export OM2G_MAXNN=1750
export OM2G_MARGIN=300
# ---- EXPLORING STARTS: training only. Eval MUST use OM2G_SPAWN=cluster ------
export OM2G_SPAWN=explore
# ---- shaping, CALIBRATED today against sigma(D_i)=3.78 ----------------------
# targets: fiedler 0.10*sigma, voronoi 0.05, edge 0.02, spread off
export OM2G_SHAPE_FIEDLER=15.79
export OM2G_SHAPE_VORONOI=3.285
export OM2G_SHAPE_EDGE=0.9522
export OM2G_SHAPE_SPREAD=0
export OM2G_EXTRA_OVERRIDES="experiment.lr=2.5e-4 experiment.checkpoint_interval=24000"
export OM2G_RUN_TAG=c6ent001
export OM2G_TMPDIR=/usr/itetnas04/data-scratch-01/eguzys/data/tmp/c6ent001
mkdir -p $OM2G_TMPDIR
export OMNET_ALGO=padre_mappo_norm_ent0.001
export OMNET_EXPECT_ENT=0.001
cd /usr/itetnas04/data-scratch-01/eguzys/data/resilient-backbone
bash om2g/om2g_launch_arton.sh compressed st 0 300000
