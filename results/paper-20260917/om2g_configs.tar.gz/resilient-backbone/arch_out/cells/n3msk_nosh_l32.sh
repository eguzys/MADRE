#!/bin/bash
#SBATCH --job-name=n3msk_nosh_l32
#SBATCH -o /usr/itetnas04/data-scratch-01/eguzys/data/resilient-backbone/om2g_logs/cells/n3msk_nosh_l32.out
#SBATCH -e /usr/itetnas04/data-scratch-01/eguzys/data/resilient-backbone/om2g_logs/cells/n3msk_nosh_l32.err
#SBATCH --cpus-per-task=20
#SBATCH --mem=48G
#SBATCH --time=48:00:00
#SBATCH -p cpu.normal
# ---- the banded archipelago -------------------------------------------------
export OM2G_USER_SPAWN=archipelago
export OM2G_CLUSTERS=4
export OM2G_ARENA=3800
export OM2G_SPREAD=25
export OM2G_PCROSS=0.9
export OM2G_DRONES=8
export OMNET_NUM_DRONES=8
export OM2G_MINSEP=1465
export OM2G_MAXNN=1750
export OM2G_MARGIN=300
# ---- EXPLORING STARTS: training only. Eval MUST use OM2G_SPAWN=cluster ------
export OM2G_SPAWN=explore
# ---- shaping, CALIBRATED today against sigma(D_i)=3.78 ----------------------
# targets: fiedler 0.10*sigma, voronoi 0.05, edge 0.02, spread off
export OM2G_SHAPE_FIEDLER=15.79
export OM2G_SHAPE_VORONOI=3.285
export OM2G_SHAPE_EDGE=0.9522
export OM2G_SHAPE_SPREAD=0
export OM2G_EXTRA_OVERRIDES="experiment.lr=2.5e-4 experiment.checkpoint_interval=24000"
export OM2G_RUN_TAG=n3msk_nosh_l32
export OM2G_TMPDIR=/usr/itetnas04/data-scratch-01/eguzys/data/tmp/n3msk_nosh_l32
mkdir -p $OM2G_TMPDIR
export OM2G_EXTRA_OVERRIDES="experiment.lr=1e-3 experiment.checkpoint_interval=24000"
export OMNET_ALLOW_CPU=1
export OM2G_LP_PRUNE_BPS=100
export OMP_NUM_THREADS=8
export MKL_NUM_THREADS=8
export OM2G_EXTRA_OVERRIDES="$OM2G_EXTRA_OVERRIDES experiment.sampling_device=cpu experiment.train_device=cpu experiment.buffer_device=cpu"
export OM2G_SHAPE_FIEDLER=0
export OM2G_SHAPE_VORONOI=0
export OM2G_SHAPE_EDGE=0
export OMNET_PEER_LINK_MASK=1
export OM2G_LATENT_DIM=32
cd /usr/itetnas04/data-scratch-01/eguzys/data/resilient-backbone
bash om2g/om2g_launch_arton.sh compressed st 0 300000
