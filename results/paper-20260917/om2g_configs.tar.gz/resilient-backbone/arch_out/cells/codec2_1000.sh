#!/bin/bash
#SBATCH --job-name=codec2_1000
#SBATCH -o /usr/itetnas04/data-scratch-01/eguzys/data/resilient-backbone/om2g_logs/cells/codec2_1000.out
#SBATCH -e /usr/itetnas04/data-scratch-01/eguzys/data/resilient-backbone/om2g_logs/cells/codec2_1000.err
#SBATCH --cpus-per-task=10
#SBATCH --mem=48G
#SBATCH --time=8:00:00
export OM2G_USER_SPAWN=archipelago
export OM2G_CLUSTERS=4
export OM2G_ARENA=3800
export OM2G_SPREAD=25
export OM2G_PCROSS=0.9
export OM2G_DRONES=8
export OMNET_NUM_DRONES=8
export OM2G_MINSEP=1000
export OM2G_MAXNN=1200
export OM2G_MARGIN=300
export OMNET_ALLOW_CPU=1
export OM2G_LP_PRUNE_BPS=100
export OM2G_CTRL_SPREADING=8
export OM2G_PHYSICAL_METRIC=1
export OM2G_USER_PARTNER_TAG=1
export OM2G_PARTNER_TAG_MODE=group
export OM2G_PEER_MEMORY=1
export OM2G_SPAWN=cluster
export OM2G_TRACK=1
export OMP_NUM_THREADS=8
cd /usr/itetnas04/data-scratch-01/eguzys/data/resilient-backbone
export SCRATCH=/usr/itetnas04/data-scratch-01/eguzys/data
source $SCRATCH/miniconda3/etc/profile.d/conda.sh; conda activate $SCRATCH/padre_env
export OMNET_APPTAINER_SIF=$SCRATCH/omnet.sif OMNET_HOST_CODE=/usr/itetnas04/data-scratch-01/eguzys/data/resilient-backbone OMNET_CONTAINER_CODE=/work
export OMNET_INET_DIR=/opt/inet4.6 OMNETPP_DIR=/opt/omnetpp-6.4.0
mkdir -p codec_data codecs
eval "$(python om2g/om2g_config.py --arm nocontrol --shell)"
python om2g/om2g_collect_codec_data.py --episodes 160 --seed 1 --out codec_data/om2g_sets_1000_s1.npz || exit 1
for L in 1 2 4 8 16 32 56 128; do
  python src/encoder_experiments/train_frozen_omnet_encoder.py --npz "codec_data/om2g_sets_1000*.npz" --output $L --out codecs/om2g_codec_1000_o${L}_v2.pt || echo "CODEC L=$L FAILED"
done
echo === CODEC V2 BUILD DONE 1000 ===
