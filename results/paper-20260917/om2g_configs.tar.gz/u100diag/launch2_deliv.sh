#!/bin/bash
# Population-generic OM2G eval launcher (scratch copy; works on tik42x/tik43x/arton nodes).
# Args: <cell-tag> <users> <seed_start> <episodes> <ckpt rel to src or "best"> <out-name>
# Env (optional): DIAG_SENDERPROB=<p>  injects --*.rlBridge.senderProb=<p> into OMNET_EXTRA_ARGS after om2g_config.
#                 DIAG_TELEM=0 disables telemetry/trace/hook dumps (they are on by default).
TAG=$1; USERS=$2; SS=$3; EP=$4; CK=$5; NAME=$6
S=/usr/itetnas04/data-scratch-01/eguzys/data/u100diag
mkdir -p $S/out $S/logs
export DIAG_HOME=$S
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
# capture the simulator stdout so TRAFFIC:/DELIVERED: survive (read at IMPORT time)
export OMNET_LOG_STDOUT=$S/delivered/sim_${6}_s${3}.log
# $DIAG_SPAWN overrides the drone spawn. "cluster" (the historical default)
# places every drone ON a user cluster, which hands the policy the demand
# geometry before step 0 -- silence needs no message because it was already
# told the answer. "uniform" decorrelates the spawn from the users.
export OM2G_SPAWN_FORCE=${DIAG_SPAWN:-cluster}
export OM2G_OUT_SUFFIX=_${NAME}
if [ "$USERS" != "40" ]; then export OM2G_USERS=$USERS; else unset OM2G_USERS; fi
POST=""
if [ -n "${DIAG_SENDERPROB:-}" ]; then
  POST="export OMNET_EXTRA_ARGS=\"\$OMNET_EXTRA_ARGS --*.rlBridge.senderProb=${DIAG_SENDERPROB}\""
fi
# $OM2G_DEMAND_ALPHA / $OM2G_DEMAND_FLOOR are read by RLBridge.cc through
# getenv, not through OMNET_EXTRA_ARGS, so they only need to reach the sim's
# environment -- ew.sh re-exports every OM2G_* line it is handed.
[ -n "${DIAG_ALPHA:-}" ] && POST="$POST
export OM2G_DEMAND_ALPHA=${DIAG_ALPHA}"
[ -n "${DIAG_FLOOR:-}" ] && POST="$POST
export OM2G_DEMAND_FLOOR=${DIAG_FLOOR}"
[ -n "$POST" ] && export OM2G_EXTRA_POST="$POST"
RUN=${NAME}_s${SS}
if [ "${DIAG_TELEM:-1}" = "1" ]; then
  export OM2G_DUMP_TRACE=$S/out/trace_${RUN}.json
  export OM2G_TELEMETRY_CSV=$S/out/telem_${RUN}.csv
fi
export HOOK_OUT=$S/out/hook_${RUN}.json
[ "$CK" != "best" ] && export DIAG_CKPT="$CK"
cd /usr/itetnas04/data-scratch-01/eguzys/data/resilient-backbone
exec bash $S/ew.sh "$TAG" "$EP" "$SS" "${DIAG_MINSEP:-}" > $S/logs/${RUN}.log 2>&1
