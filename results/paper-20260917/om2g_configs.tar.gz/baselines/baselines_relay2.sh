#!/bin/bash
# Launcher for the two relay-planner baselines (evaluate_relay2.py).
# Each arm is charged for what it actually transmits.
set -uo pipefail

POLICY="${1:-relay_priced}"
EPISODES="${2:-100}"
SEED_START="${3:-0}"

export SLURM_CONF=/home/sladmitet/slurm/slurm.conf
SCRATCH=/usr/itetnas04/data-scratch-01/eguzys/data
RB=$SCRATCH/resilient-backbone
F=$SCRATCH/u100diag/relay
export TMPDIR=$SCRATCH/tmp
source $SCRATCH/miniconda3/etc/profile.d/conda.sh
conda activate $SCRATCH/padre_env
cd "$RB"

export OM2G_TRACK=1
eval "$(python om2g/om2g_config.py --arm compressed --shell)"; [ -n "${DIAG_SENDERPROB:-}" ] && export OMNET_EXTRA_ARGS="$OMNET_EXTRA_ARGS --*.rlBridge.senderProb=$DIAG_SENDERPROB"

REAL_POLICY=hover
RUNNER="$F/evaluate_relay2.py"
export RELAY_POLICY=$POLICY
export OM2G_RELAY_MODE=${OM2G_RELAY_MODE:-blind}

msg() { python3 -c "import sys;sys.path.insert(0,'$RB/om2g');import om2g_track as T;print(T.om2g_message_on_air_bytes('$1',${2:-8}))"; }
beacon() { python3 -c "import sys;sys.path.insert(0,'$RB/om2g');import om2g_track as T;print(T.om2g_beacon_on_air_bytes())"; }

case "${POLICY:-}" in
  relay_priced)
    # Acts on the pooled heard-user set: billed as an uncompressed user block.
    export OM2G_CONTROL_ON_AIR_BYTES=$(msg uncompressed) ;;
  relay_1hop)
    # Sends only a one-hop neighbour round: billed as a position beacon.
    export OM2G_CONTROL_ON_AIR_BYTES=$(beacon) ;;
  *)
    echo "relay2: unknown POLICY='${POLICY:-}' -- refusing to guess a charge" >&2
    exit 2 ;;
esac

echo "[charge] POLICY=${POLICY} REAL_POLICY=${REAL_POLICY} OM2G_CONTROL_ON_AIR_BYTES=${OM2G_CONTROL_ON_AIR_BYTES} RELAY_MODE=${OM2G_RELAY_MODE}"

export OMNET_APPTAINER_SIF=$SCRATCH/omnet.sif
export OMNET_HOST_CODE=$RB
export OMNET_CONTAINER_CODE=/work
export OMNET_INET_DIR=/opt/inet4.6
export OMNETPP_DIR=/opt/omnetpp-6.4.0
export CUDA_VISIBLE_DEVICES=""

mkdir -p "$F/out"
OUT="$F/out/OM2G_baseline_${POLICY}_N${OM2G_DRONES:-5}_n${EPISODES}${OM2G_RUN_TAG:+_${OM2G_RUN_TAG}}_seed${SEED_START}.csv"
echo "  RELAY BASELINE - policy=$POLICY  N=${OM2G_DRONES:-5}  episodes=$EPISODES  spawn=${OM2G_SPAWN:-default}"
echo "  MINSEP=${OM2G_MINSEP:-} MAXNN=${OM2G_MAXNN:-} CLUSTERS=${OM2G_CLUSTERS:-} USERS=${OM2G_USERS:-40} SENDERPROB=${DIAG_SENDERPROB:-1.0}"
echo "  out=$OUT"

cd omnet_module
exec python "$RUNNER" \
  --policy "$REAL_POLICY" \
  --num-drones ${OM2G_DRONES:-5} \
  --episodes "$EPISODES" \
  --seed-start "$SEED_START" \
  --out "$OUT"
