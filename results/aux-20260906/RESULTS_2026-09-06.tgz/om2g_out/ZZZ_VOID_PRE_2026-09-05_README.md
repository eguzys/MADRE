# ⚠️ VOID — DO NOT USE ANYTHING IN THIS DIRECTORY DATED BEFORE 2026-09-05

`om2g_out/` is a working directory that accumulated results across several
code generations. Files written **before 2026-09-05** are VOID and must never
be mixed with current numbers. Three defects, each sufficient on its own:

1. **The delivered-content defect.** Every compressed arm was CHARGED for a
   small beacon but DELIVERED the sender's full 680-float user block. The
   compression ladder, the talk-vs-silent comparison and Claim 1 are all void
   before this was fixed.
2. **The eval path never built an OM2G environment.** `evaluate_omnet.py`
   unconditionally constructed the BASE env, so no OM2G checkpoint could be
   scored at all. Every score produced before the fix is meaningless.
3. **`nocontrol` was never silent.** It beaconed 4 B/s, and any arriving
   beacon delivered the full snapshot, so historical "talking beats silence"
   compared full-info against full-info.

## Where the valid results are

`RESULTS_2026-09-06/` — curated, post-fix only, with its own README.

## How current files are identified

By CELL NAME, not by date — the fixes landed mid-day on 2026-09-05 so dates
are ambiguous. The authoritative cell list is in
`RESULTS_2026-09-06/README.md`.

## Two further caveats that apply to SOME current results

- **1200 m shaping is miscalibrated.** The shaping triple in the 1200 m cells
  is 6.9-12.6x too large (deployed 65.97/33.24/9.089; correct
  9.603/2.789/0.7233). Scores are still honest — evaluation measures true
  max-flow throughput, not the shaped signal — but the policies were trained
  under a helper reward at ~60% of the task signal instead of the designed
  ~10%. The `br12fix*` cells test whether the 1200 m ranking survives
  correction. The 1600 m cells are correctly calibrated.
- **Spawn.** 1200 m and 1000 m cells TRAIN at explore spawn; the ladder is
  scored at CLUSTER spawn in the `_SPAWNcluster` CSV family. Never pool a
  `_SPAWNcluster` file with an un-suffixed one — spawn REVERSES arm rankings.
