# OM2G RESULTS — curated 2026-09-06

Everything in this folder was produced **after the 2026-09-05 fixes**
(delivered-content defect, the eval path never building an OM2G environment,
and the non-silent `nocontrol` arm). Nothing here predates those.

Anything in `../om2g_out/` dated before 2026-09-05 is VOID — see
`../om2g_out/ZZZ_VOID_PRE_2026-09-05_README.md`.

## Contents

- `eval_csv/`  666 eval CSVs, n=100 episodes per cell, one row per episode seed
- `traces/`    8 position-trace JSONs (12 episodes each) used for the mechanism
               and flow-decomposition analyses
- `logs/`      8 call-grade outputs (per-call VOICE / SLOW / DEAD)
- `tables/`    the computed tables below

## The authoritative cells

**1200 m** (scored at CLUSTER spawn, `_SPAWNcluster` family — these cells TRAIN
at explore spawn, so the un-suffixed CSVs are a DIFFERENT experiment):
  v1200noc_s1/s2/s3, v1200e2eL8s1/s2, v1200e2eL32s1/s2/s3,
  v1200e2eL128s1/s2, v1200unc_s1/s2
**1600 m** (train and score at cluster spawn, un-suffixed):
  v1600noc_s1/s2/s3, v1600e2eL8s1/s2, v1600e2eL32s1/s2,
  v1600e2eL128s1/s2, v1600unc_s1/s2
**Content ablation, 1200 m** (`_SPAWNcluster`):
  v1200hUsrL32s1/s2, v1200hNonL32s1, v1200hNonL8s1, v1200hNonL128s1,
  v1200hAggL32s1

## Reading rules — these have each caused a wrong conclusion before

1. **Never pool `_SPAWNcluster` with un-suffixed files.** Spawn REVERSES arm
   rankings; it is a category error, not a small bias.
2. **Never glob on `_n5_seed*`.** Some cells were evaluated with chunk n=3, and
   an `_n5_` glob silently drops them and reports a smaller n with no error.
   Use `_n*_seed*`.
3. **`_trc` files are 12-episode trace runs, not scoring runs.** They cannot be
   swept into a scoring glob because `<cell>_n` does not match `<cell>_trc_n`.
4. **Quote no OM2G number without its cluster separation.** Margins swing by
   more than 2x between 1200 m and 1600 m.
5. **Report seed-level AND episode-paired statistics.** Episode-paired treats
   the training seed as fixed; training-seed spread is ~4000 reward points at
   1200 m, so an episode-paired t of +9 can be ~2 sigma against seed noise.

## Known caveats on these results

- **1200 m shaping is 6.9-12.6x too large** (deployed 65.97/33.24/9.089;
  correct 9.603/2.789/0.7233). Scores are honest — evaluation measures true
  throughput — but policies trained under a helper reward at ~60% of the task
  signal rather than ~10%. `br12fix*` cells test whether the 1200 m ranking
  survives correction. **1600 m is correctly calibrated.**
- Every hNon/hAgg number is ONE training seed.
- The argmax is NOT established: L128 wins at 1200 m; at 1600 m L128 and L32
  are indistinguishable (seed-level t=-0.10).
